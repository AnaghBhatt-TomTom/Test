using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace Company.Function
{
    public static class ConstructSPURL
    {
        [FunctionName("ConstructSPURL")]
        public static async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Anonymous, "get", "post", Route = null)] HttpRequest req,
            ILogger log)
        {
             string FileName = req.Query["FileName"];
             string URL = "";
             string Country = "";
              string fileWithoutExt = Path.GetFileNameWithoutExtension(FileName);
           //FileName = FileName.Remove(FileName.Length -4);
           string countryCode = fileWithoutExt.Substring(fileWithoutExt.Length - 2);
           Country = getReportCountryName(countryCode);
          URL = Country + "/Reports";
          string responseMessage = URL;

return new OkObjectResult(responseMessage);
        }

public static string getReportCountryName(string CountryCode)
{
    string countryName = "";

    switch (CountryCode.ToUpper())
    {
        case "AT":
            countryName = "Austria";
            break;
        case "DE":
            countryName = "Germany";
            break;
        case "DK":
            countryName = "Denmark";
            break;
        case "FI":
            countryName = "Finland";
            break;
        case "IT":
            countryName = "Italy";
            break;
        case "NO":
            countryName = "Norway";
            break;
        case "PT":
            countryName = "Portugal";
            break;
        case "ZA":
            countryName = "South Africa";
            break;
        case "ES":
            countryName = "Spain";
            break;
        case "SE":
            countryName = "Sweden";
            break;
        case "TR":
            countryName = "Turkey";
            break;
        case "GB":
            countryName = "UK";
            break;
        case "PL":
            countryName = "Poland";
            break;
        case "FR":
            countryName = "France";
            break;
        case "BE":
            countryName = "Belgium";
            break;
        case "IN":
            countryName = "India";
            break;
        case "NL":
            countryName = "Netherlands";
            break;
        case "SB":
            countryName = "Serbia";
            break;
        case "TW":
            countryName = "Taiwan";
            break;
        case "US":
            countryName = "US";
            break;


    }

    return countryName;
}

    }
}
